from django.db import models


# Create your models here.

class Videos(models.Model):
     videoo = models.FileField(upload_to='videos/', null=True, verbose_name="")
     summary = models.CharField(max_length=500)
     image = models.ImageField(upload_to='videos/',null=True)

     def __str__(self):
        return self.summary

class showsimage(models.Model):
      pics = models.ImageField(upload_to='images/',null=True)

      
class ourwork(models.Model):
        work = models.ImageField(upload_to='images/',null=True)
        summaryy = models.CharField(max_length=50)

        