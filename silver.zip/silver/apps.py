from django.apps import AppConfig


class SilverConfig(AppConfig):
    name = 'silver'
