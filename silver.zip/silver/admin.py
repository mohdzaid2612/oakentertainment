from django.contrib import admin

from .models import Videos, showsimage,ourwork

admin.site.register(Videos)
admin.site.register(showsimage)
admin.site.register(ourwork)
